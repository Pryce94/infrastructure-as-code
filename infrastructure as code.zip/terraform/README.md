# Terraform Projects

This is a collection of terraform projects for working with lesson resources.

## stack-adminsetup

This is to set up the initial OpenStack admin resources.

## stack-tenants

This project sets up initial tenant accounts.

## stack-modules

This combines the previous two projects as modules, and shows some file
organization.
