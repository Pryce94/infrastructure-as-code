# Automated OpenStack Lab Setup

While you should run through these lab steps to truly understand them, this is
provided so that you can delete and recreate the lab quickly.

Three steps:
- run init-hypervisor
- run vagrant up with provided Vagrantfile
- log in and run the setup.sh script
