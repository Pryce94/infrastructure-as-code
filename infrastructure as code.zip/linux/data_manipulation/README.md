This section is for working with datasets and manipulating strings. This can be
used for scripting, or for basic day to day operations in the Linux CLI.

### Resources:

- [RegExr.com](https://regexr.com) - A free learning environment for regex
- [Data IAP Course Datasets](https://github.com/dataiap/dataiap/tree/master/datasets) - Open course materials from MIT

