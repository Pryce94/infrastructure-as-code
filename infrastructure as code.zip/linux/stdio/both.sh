#!/usr/bin/env bash
echo stdout
echo stderr 1>&2
