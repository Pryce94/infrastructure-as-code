#!/usr/bin/env bash
echo stdout
exit 0
