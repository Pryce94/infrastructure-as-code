#!/usr/bin/env bash
echo stderr 1>&2
exit 1
