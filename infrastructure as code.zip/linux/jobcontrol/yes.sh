#!/bin/bash
echo yes
exit 0
